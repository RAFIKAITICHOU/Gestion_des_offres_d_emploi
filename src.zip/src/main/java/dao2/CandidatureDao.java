/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao2;

/**
 *
 * @author ichou
 */
import entities.Candidature;

public class CandidatureDao extends AbstractDao<Candidature> {

    public CandidatureDao() {
        super(Candidature.class);
    }
}
